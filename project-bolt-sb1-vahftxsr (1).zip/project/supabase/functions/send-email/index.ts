import { createClient } from 'npm:@supabase/supabase-js@2.39.3'
import { z } from 'npm:zod@3.22.4'
import nodemailer from 'npm:nodemailer@6.9.9'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

const emailSchema = z.object({
  email: z.string().email('Invalid email address'),
  subject: z.string().min(1, 'Subject cannot be empty').max(100, 'Subject too long'),
  message: z.string().min(1, 'Message cannot be empty').max(5000, 'Message too long'),
})

const rateLimit = new Map<string, { count: number; timestamp: number }>()

const checkRateLimit = (ip: string): boolean => {
  const now = Date.now()
  const limit = rateLimit.get(ip)
  
  if (!limit) {
    rateLimit.set(ip, { count: 1, timestamp: now })
    return true
  }

  if (now - limit.timestamp > 3600000) { // 1 hour
    rateLimit.set(ip, { count: 1, timestamp: now })
    return true
  }

  if (limit.count >= 10) { // 10 emails per hour
    return false
  }

  limit.count++
  return true
}

const validateEnvironment = () => {
  const requiredEnvVars = ['SMTP_HOST', 'SMTP_PORT', 'SMTP_USER', 'SMTP_PASS']
  const missingVars = requiredEnvVars.filter(varName => !Deno.env.get(varName))
  
  if (missingVars.length > 0) {
    throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`)
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    validateEnvironment()

    const { email, subject, message } = await req.json()
    
    const validation = emailSchema.safeParse({ email, subject, message })
    if (!validation.success) {
      const errors = validation.error.errors.map(err => `${err.path}: ${err.message}`).join(', ')
      return new Response(
        JSON.stringify({ error: errors }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    const clientIp = req.headers.get('x-forwarded-for') || 'unknown'
    if (!checkRateLimit(clientIp)) {
      return new Response(
        JSON.stringify({ 
          error: 'Rate limit exceeded. Please try again later.',
          retryAfter: '1 hour'
        }),
        { 
          status: 429, 
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Retry-After': '3600'
          } 
        }
      )
    }

    const transporter = nodemailer.createTransport({
      host: Deno.env.get('SMTP_HOST'),
      port: parseInt(Deno.env.get('SMTP_PORT') || '587'),
      secure: Deno.env.get('SMTP_PORT') === '465',
      auth: {
        user: Deno.env.get('SMTP_USER'),
        pass: Deno.env.get('SMTP_PASS'),
      },
    })

    await transporter.sendMail({
      from: Deno.env.get('SMTP_USER'),
      to: email,
      subject,
      text: message,
      headers: {
        'X-Priority': '3', // Normal priority
      }
    })

    return new Response(
      JSON.stringify({ 
        message: 'Email sent successfully',
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  } catch (error) {
    console.error('Error sending email:', error)
    
    const errorMessage = error instanceof Error ? error.message : 'Failed to send email'
    return new Response(
      JSON.stringify({ 
        error: errorMessage,
        timestamp: new Date().toISOString()
      }),
      { 
        status: 500, 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})